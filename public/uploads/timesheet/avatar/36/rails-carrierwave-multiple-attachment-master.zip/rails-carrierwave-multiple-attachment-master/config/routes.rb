Rails.application.routes.draw do
  resources :post_attachments
  resources :posts
end