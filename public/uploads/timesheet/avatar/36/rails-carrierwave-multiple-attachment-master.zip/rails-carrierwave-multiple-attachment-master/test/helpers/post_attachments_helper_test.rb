require 'test_helper'

class PostAttachmentsHelperTest < ActionView::TestCase
end
